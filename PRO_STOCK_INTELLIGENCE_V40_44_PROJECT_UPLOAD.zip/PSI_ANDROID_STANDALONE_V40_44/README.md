# PRO STOCK INTELLIGENCE — V40.44 Standalone Android

This is a **standalone Android WebView application** based on the V40.39 dashboard.

- No Python/local server on the phone or laptop.
- Dashboard HTML is bundled inside the APK using Android `WebViewAssetLoader`.
- `/api/*` calls are intercepted by the native Android provider.
- Live/recent quote and OHLCV: Yahoo Finance.
- Fundamentals: public Screener.in company pages.
- Technical calculations remain in the dashboard.
- Desktop Screener authenticated session is not transferred to Android.

## Build without Android Studio

This repository includes `.github/workflows/build-apk.yml`.
Create a GitHub repository, upload the project, then open **Actions → Build PRO STOCK INTELLIGENCE APK → Run workflow**. The generated `app-debug.apk` is published as a workflow artifact.

## Important

The APK itself cannot be generated in this source package without an Android SDK/Gradle build environment. The GitHub Actions workflow supplies that cloud build environment.

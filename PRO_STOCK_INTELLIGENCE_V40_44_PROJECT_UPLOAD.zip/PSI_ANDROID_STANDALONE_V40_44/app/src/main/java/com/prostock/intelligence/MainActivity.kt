package com.prostock.intelligence

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import android.net.Uri
import android.graphics.Color
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val provider = NativeProvider()

    private fun jsonResponse(json: String): WebResourceResponse =
        WebResourceResponse("application/json", "UTF-8", ByteArrayInputStream(json.toByteArray(Charsets.UTF_8)))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(237,245,251))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net" && uri.path?.startsWith("/api/") == true) {
                    return try {
                        jsonResponse(provider.handle(uri.encodedPath + (uri.encodedQuery?.let { "?$it" } ?: "")))
                    } catch (e: Exception) {
                        jsonResponse("{\"ok\":false,\"error\":${org.json.JSONObject.quote(e.message ?: "Provider error")}}")
                    }
                }
                return assetLoader.shouldInterceptRequest(uri)
            }

            @Suppress("DEPRECATION")
            override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? {
                val uri = Uri.parse(url)
                if (uri.scheme == "https" && uri.host == "appassets.androidplatform.net" && uri.path?.startsWith("/api/") == true) {
                    return try { jsonResponse(provider.handle(uri.encodedPath + (uri.encodedQuery?.let { "?$it" } ?: ""))) }
                    catch (e: Exception) { jsonResponse("{\"ok\":false,\"error\":${org.json.JSONObject.quote(e.message ?: "Provider error")}}") }
                }
                return assetLoader.shouldInterceptRequest(uri)
            }
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

class NativeProvider {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 18000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) PRO-STOCK-INTELLIGENCE/1.0")
        c.setRequestProperty("Accept", "application/json,text/html,*/*")
        return c.inputStream.bufferedReader().use { it.readText() }
    }
    private fun sym(raw:String)=raw.trim().uppercase().removeSuffix(".NS").removeSuffix(".BO")
    private fun yahoo(s:String, range:String="1y"): JSONObject {
        val x=sym(s); val url="https://query1.finance.yahoo.com/v8/finance/chart/${URLEncoder.encode(x+".NS","UTF-8")}?range=$range&interval=1d&events=history"
        val root=JSONObject(get(url)); val r=root.getJSONObject("chart").getJSONArray("result").getJSONObject(0)
        val meta=r.getJSONObject("meta"); val q=r.getJSONArray("indicators").getJSONArray("quote").getJSONObject(0); val ts=r.getJSONArray("timestamp")
        val rows=JSONArray(); for(i in 0 until ts.length()) { val o=q.optJSONArray("open")?.optDouble(i,Double.NaN) ?: Double.NaN; val h=q.optJSONArray("high")?.optDouble(i,Double.NaN) ?: Double.NaN; val l=q.optJSONArray("low")?.optDouble(i,Double.NaN) ?: Double.NaN; val c=q.optJSONArray("close")?.optDouble(i,Double.NaN) ?: Double.NaN; val v=q.optJSONArray("volume")?.optLong(i,0) ?: 0; if(c.isNaN()) continue; rows.put(JSONObject().apply{put("date",ts.optLong(i)*1000);put("open",o);put("high",h);put("low",l);put("close",c);put("volume",v)}) }
        return JSONObject().apply { put("price",meta.optDouble("regularMarketPrice",Double.NaN)); put("previousClose",meta.optDouble("previousClose",Double.NaN)); put("currency",meta.optString("currency","INR")); put("rows",rows); put("provider","Yahoo Finance") }
    }
    private fun screener(s:String): JSONObject {
        val html=get("https://www.screener.in/company/${sym(s)}/")
        fun num(label:String):Double? { val re=Regex("${Regex.escape(label)}\\s*</span>\\s*<span[^>]*>\\s*₹?\\s*([0-9,.]+)",RegexOption.IGNORE_CASE); val m=re.find(html); return m?.groupValues?.get(1)?.replace(",","")?.toDoubleOrNull() }
        fun pct(label:String):Double? { val re=Regex("${Regex.escape(label)}\\s*</span>\\s*<span[^>]*>\\s*([0-9,.]+)\\s*%",RegexOption.IGNORE_CASE); return re.find(html)?.groupValues?.get(1)?.replace(",","")?.toDoubleOrNull() }
        val f=JSONObject(); num("Current Price")?.let{f.put("price",it)}; num("Market Cap")?.let{f.put("marketCap",it)}; num("Stock P/E")?.let{f.put("pe",it)}; num("Book Value")?.let{f.put("bookValue",it)}; pct("Dividend Yield")?.let{f.put("dividendYield",it)}; pct("ROCE")?.let{f.put("roce",it)}; pct("ROE")?.let{f.put("roe",it)}; num("Debt / Equity")?.let{f.put("debtEquity",it)}; num("EPS in Rs")?.let{f.put("eps",it)}
        val name=Regex("<h1[^>]*>\\s*([^<]+)",RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)?.trim() ?: s
        f.put("name",name); return f
    }
    fun handle(path:String):String {
        val p=path.substringBefore("?"); val query=path.substringAfter("?","").split("&").mapNotNull{val a=it.split("=",limit=2);if(a.size==2)a[0] to java.net.URLDecoder.decode(a[1],"UTF-8") else null}.toMap(); val s=sym(query["symbol"]?:query["q"]?:"INFY")
        return when(p) {
            "/api/screener/status","/api/screener/connect" -> JSONObject().put("ok",true).put("data",JSONObject().put("connected",false).put("loggedIn",false).put("message","Android app uses direct verified public providers; desktop Screener session is not available on Android." )).toString()
            "/api/search-suggestions" -> JSONObject().put("ok",true).put("data",JSONArray().put(JSONObject().put("symbol",s).put("name",s).put("exchange","NSE").put("sector","Equity"))).toString()
            "/api/quote","/api/fast" -> { val y=yahoo(s,"5d"); JSONObject().put("ok",true).put("data",JSONObject().put("symbol",s).put("name",s).put("quote",y).put("provider","Yahoo Finance")).toString() }
            "/api/history" -> { val y=yahoo(s,query["range"]?:"1y"); JSONObject().put("ok",true).put("data",JSONObject().put("symbol",s).put("rows",y.getJSONArray("rows")).put("provider","Yahoo Finance")).toString() }
            "/api/analyze","/api/bootstrap" -> { val y=yahoo(s,"1y"); val f=screener(s); val market=JSONObject(y.toString()); val keys=arrayOf("name","price","marketCap","pe","bookValue","dividendYield","roce","roe","debtEquity","eps"); for(k in keys)if(f.has(k))market.put(k,f.get(k)); val data=JSONObject().put("symbol",s).put("name",f.optString("name",s)).put("market",market).put("fundamentals",f).put("quote",y).put("ohlcv",y.getJSONArray("rows")).put("technicalSeries",y.getJSONArray("rows")).put("dataConfidence","PARTIAL").put("dataSources",JSONObject().put("Screener.in","PUBLIC HTTP").put("Live Quote","Yahoo Finance")).put("fundamentalCoverage",JSONObject().put("coreFields",f.length()).put("coreTotal",7)); JSONObject().put("ok",true).put("data",data).toString() }
            "/api/company-events" -> JSONObject().put("ok",true).put("data",JSONObject().put("events",JSONArray()).put("status","Not available in Android direct-provider mode")).toString()
            "/api/peers","/api/news","/api/indices" -> JSONObject().put("ok",true).put("data",JSONObject().put("items",JSONArray()).put("status","Provider not configured yet")).toString()
            else -> JSONObject().put("ok",false).put("error","Unsupported mobile API: $p").toString()
        }
    }
}
